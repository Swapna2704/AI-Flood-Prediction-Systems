"""
predict.py
-----------
Loads the trained model + scaler and exposes a predict_flood() function
that other modules (like the Flask app) can import.
"""

import os

import joblib
import pandas as pd

MODEL_DIR = os.path.dirname(os.path.abspath(__file__))

FEATURES = [
    "rainfall_mm",
    "water_level_m",
    "humidity_percent",
    "temperature_c",
    "river_discharge_cumecs",
    "soil_moisture_percent",
    "elevation_m",
    "days_since_last_rain",
]

_model = None
_scaler = None


def _load():
    global _model, _scaler
    if _model is None or _scaler is None:
        model_path = os.path.join(MODEL_DIR, "flood_model.pkl")
        scaler_path = os.path.join(MODEL_DIR, "scaler.pkl")
        if not os.path.exists(model_path):
            raise FileNotFoundError(
                "Trained model not found. Run `python model/train_model.py` first."
            )
        _model = joblib.load(model_path)
        _scaler = joblib.load(scaler_path)
    return _model, _scaler


def predict_flood(input_dict: dict) -> dict:
    """
    input_dict must contain all keys in FEATURES.
    Returns dict with prediction label, probability, and risk level.
    """
    model, scaler = _load()

    x = pd.DataFrame([[input_dict[f] for f in FEATURES]], columns=FEATURES)
    x_scaled = scaler.transform(x)

    pred = int(model.predict(x_scaled)[0])
    proba = float(model.predict_proba(x_scaled)[0][1])  # probability of flood

    if proba < 0.3:
        risk_level = "Low"
    elif proba < 0.6:
        risk_level = "Moderate"
    elif proba < 0.85:
        risk_level = "High"
    else:
        risk_level = "Severe"

    return {
        "flood_predicted": bool(pred),
        "flood_probability": round(proba, 4),
        "risk_level": risk_level,
    }


if __name__ == "__main__":
    sample = {
        "rainfall_mm": 180,
        "water_level_m": 7.2,
        "humidity_percent": 88,
        "temperature_c": 26,
        "river_discharge_cumecs": 420,
        "soil_moisture_percent": 82,
        "elevation_m": 40,
        "days_since_last_rain": 0.5,
    }
    print(predict_flood(sample))
