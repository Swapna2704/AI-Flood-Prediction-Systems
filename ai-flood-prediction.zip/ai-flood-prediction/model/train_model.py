"""
train_model.py
----------------
Trains a Random Forest classifier on the flood dataset and saves:
    - model/flood_model.pkl   (trained model)
    - model/scaler.pkl        (feature scaler)
    - model/metrics.json      (evaluation metrics)
    - model/feature_importance.png

Run:
    python model/train_model.py
"""

import json
import os
import sys

import joblib
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
    roc_auc_score,
)
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

# Ensure project root is on path when run directly
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

FEATURES = [
    "rainfall_mm",
    "water_level_m",
    "humidity_percent",
    "temperature_c",
    "river_discharge_cumecs",
    "soil_moisture_percent",
    "elevation_m",
    "days_since_last_rain",
]
TARGET = "flood_occurred"

DATA_PATH = os.path.join("data", "flood_dataset.csv")
MODEL_DIR = "model"


def load_data(path: str = DATA_PATH) -> pd.DataFrame:
    if not os.path.exists(path):
        print("Dataset not found, generating synthetic data first...")
        from data.generate_data import generate_dataset

        df = generate_dataset()
        os.makedirs(os.path.dirname(path), exist_ok=True)
        df.to_csv(path, index=False)
        return df
    return pd.read_csv(path)


def train():
    df = load_data()
    X = df[FEATURES]
    y = df[TARGET]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)

    model = RandomForestClassifier(
        n_estimators=300,
        max_depth=10,
        min_samples_split=5,
        random_state=42,
        class_weight="balanced",
        n_jobs=-1,
    )
    model.fit(X_train_scaled, y_train)

    y_pred = model.predict(X_test_scaled)
    y_proba = model.predict_proba(X_test_scaled)[:, 1]

    metrics = {
        "accuracy": round(accuracy_score(y_test, y_pred), 4),
        "precision": round(precision_score(y_test, y_pred), 4),
        "recall": round(recall_score(y_test, y_pred), 4),
        "f1_score": round(f1_score(y_test, y_pred), 4),
        "roc_auc": round(roc_auc_score(y_test, y_proba), 4),
        "confusion_matrix": confusion_matrix(y_test, y_pred).tolist(),
    }

    print("=== Evaluation Metrics ===")
    for k, v in metrics.items():
        print(f"{k}: {v}")
    print("\n" + classification_report(y_test, y_pred, target_names=["No Flood", "Flood"]))

    os.makedirs(MODEL_DIR, exist_ok=True)
    joblib.dump(model, os.path.join(MODEL_DIR, "flood_model.pkl"))
    joblib.dump(scaler, os.path.join(MODEL_DIR, "scaler.pkl"))
    with open(os.path.join(MODEL_DIR, "metrics.json"), "w") as f:
        json.dump(metrics, f, indent=2)

    # Feature importance plot
    importances = pd.Series(model.feature_importances_, index=FEATURES).sort_values()
    plt.figure(figsize=(8, 5))
    importances.plot(kind="barh", color="#2563eb")
    plt.title("Feature Importance - Flood Prediction Model")
    plt.xlabel("Importance")
    plt.tight_layout()
    plt.savefig(os.path.join(MODEL_DIR, "feature_importance.png"), dpi=150)
    print(f"\nSaved model, scaler, metrics.json, feature_importance.png -> {MODEL_DIR}/")


if __name__ == "__main__":
    train()
