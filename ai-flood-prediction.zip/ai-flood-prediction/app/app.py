"""
app.py
-------
Flask web application for the AI Flood Prediction prototype.
Provides:
    - GET  /            : HTML form UI
    - POST /predict      : form submission -> renders result
    - POST /api/predict  : JSON API endpoint

Run:
    python app/app.py
Then open http://127.0.0.1:5000
"""

import os
import sys

from flask import Flask, jsonify, render_template, request

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from model.predict import FEATURES, predict_flood  # noqa: E402

app = Flask(__name__)


@app.route("/", methods=["GET"])
def index():
    return render_template("index.html", result=None)


@app.route("/predict", methods=["POST"])
def predict_form():
    try:
        input_data = {f: float(request.form[f]) for f in FEATURES}
        result = predict_flood(input_data)
        return render_template("index.html", result=result, inputs=input_data)
    except FileNotFoundError as e:
        return render_template("index.html", result=None, error=str(e))
    except Exception as e:
        return render_template("index.html", result=None, error=f"Invalid input: {e}")


@app.route("/api/predict", methods=["POST"])
def predict_api():
    """JSON API: POST body must contain all FEATURES keys as numbers."""
    try:
        data = request.get_json(force=True)
        missing = [f for f in FEATURES if f not in data]
        if missing:
            return jsonify({"error": f"Missing fields: {missing}"}), 400
        input_data = {f: float(data[f]) for f in FEATURES}
        result = predict_flood(input_data)
        return jsonify(result), 200
    except FileNotFoundError as e:
        return jsonify({"error": str(e)}), 500
    except Exception as e:
        return jsonify({"error": str(e)}), 400


if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)
