# 🌊 AI Flood Prediction System

A machine learning prototype that predicts flood risk from environmental
readings (rainfall, river water level, humidity, soil moisture, etc.) using
a Random Forest classifier, served through a Flask web app.

> ⚠️ **Disclaimer:** This is an educational/college-project prototype trained
> on synthetic data. It is **not** suitable for real-world early-warning use
> without training on verified regional flood/hydrology datasets.

---

## ✨ Features

- Synthetic dataset generator (swap in a real dataset easily — see below)
- Random Forest model with scaling, evaluation metrics, and feature-importance plot
- Flask web UI to enter readings and get a flood risk prediction
- JSON REST API endpoint (`/api/predict`) for integration with other apps
- Clean, GitHub-ready project structure

## 🗂️ Project Structure

```
ai-flood-prediction/
├── data/
│   └── generate_data.py      # synthetic dataset generator
├── model/
│   ├── train_model.py        # trains & saves the Random Forest model
│   └── predict.py            # loads model, exposes predict_flood()
├── app/
│   ├── app.py                # Flask application
│   └── templates/
│       └── index.html        # web UI
├── requirements.txt
├── .gitignore
└── README.md
```

## 🚀 Getting Started

### 1. Clone & set up environment
```bash
git clone https://github.com/<your-username>/ai-flood-prediction.git
cd ai-flood-prediction
python -m venv venv
source venv/bin/activate      # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

### 2. Generate dataset (or plug in a real one)
```bash
python data/generate_data.py
```
This creates `data/flood_dataset.csv`. To use a **real** dataset instead
(e.g. from Kaggle), just replace this CSV — keep the same column names, or
update the `FEATURES` list in `model/train_model.py` and `model/predict.py`.

### 3. Train the model
```bash
python model/train_model.py
```
Saves `model/flood_model.pkl`, `model/scaler.pkl`, `model/metrics.json`,
and a feature-importance chart.

### 4. Run the web app
```bash
python app/app.py
```
Open **http://127.0.0.1:5000** in your browser.

### 5. Or call the API directly
```bash
curl -X POST http://127.0.0.1:5000/api/predict \
  -H "Content-Type: application/json" \
  -d '{
        "rainfall_mm": 180,
        "water_level_m": 7.2,
        "humidity_percent": 88,
        "temperature_c": 26,
        "river_discharge_cumecs": 420,
        "soil_moisture_percent": 82,
        "elevation_m": 40,
        "days_since_last_rain": 0.5
      }'
```

## 📊 Model

| Detail | Value |
|---|---|
| Algorithm | Random Forest Classifier (scikit-learn) |
| Features | rainfall, water level, humidity, temperature, river discharge, soil moisture, elevation, days since last rain |
| Target | `flood_occurred` (0/1) |
| Preprocessing | StandardScaler |
| Evaluation | Accuracy, Precision, Recall, F1, ROC-AUC (see `model/metrics.json` after training) |

## 🔮 Ideas to Extend This Prototype

- Swap synthetic data for a real rainfall/river-gauge dataset (e.g. CWC / IMD / Kaggle flood datasets)
- Add time-series modeling (LSTM/GRU) using historical rainfall sequences instead of a single snapshot
- Pull live weather data via a weather API for real-time prediction
- Add a map view (Leaflet/Mapbox) showing risk by region
- Deploy on Render/Railway/Heroku and connect a SMS/WhatsApp alert system
- Add authentication + a database to log predictions over time

## 📄 License

MIT — free to use for learning, college projects, and hackathons.
