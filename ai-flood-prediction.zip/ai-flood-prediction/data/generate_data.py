"""
generate_data.py
-----------------
Synthetic dataset generator for the AI Flood Prediction prototype.

Real flood datasets (like Kaggle's "Flood Prediction Dataset" or river-basin
rainfall/water-level data) are recommended for a production model. This
script generates a realistic synthetic dataset so the prototype works
out-of-the-box without needing external downloads.

Features used:
    - rainfall_mm        : rainfall in last 24 hours (mm)
    - water_level_m       : river/reservoir water level (metres)
    - humidity_percent     : relative humidity (%)
    - temperature_c        : temperature (Celsius)
    - river_discharge_cumecs: river discharge (cubic metres/sec)
    - soil_moisture_percent : soil saturation (%)
    - elevation_m           : elevation of the monitored area (metres)
    - days_since_last_rain : dryness indicator

Target:
    - flood_occurred (0 = No flood, 1 = Flood)
"""

import numpy as np
import pandas as pd

np.random.seed(42)

N_SAMPLES = 5000


def generate_dataset(n_samples: int = N_SAMPLES) -> pd.DataFrame:
    rainfall_mm = np.random.gamma(shape=2.0, scale=40, size=n_samples)
    water_level_m = np.random.normal(loc=4.5, scale=1.8, size=n_samples).clip(0.5, 12)
    humidity_percent = np.random.normal(loc=70, scale=15, size=n_samples).clip(20, 100)
    temperature_c = np.random.normal(loc=28, scale=5, size=n_samples).clip(10, 45)
    river_discharge_cumecs = np.random.gamma(shape=2.5, scale=120, size=n_samples)
    soil_moisture_percent = np.random.normal(loc=55, scale=20, size=n_samples).clip(5, 100)
    elevation_m = np.random.normal(loc=150, scale=100, size=n_samples).clip(0, 600)
    days_since_last_rain = np.random.exponential(scale=3, size=n_samples).clip(0, 30)

    # Risk score combines the physically-relevant factors.
    # Higher rainfall, higher water level, higher discharge, higher soil
    # saturation, and lower elevation all push risk up.
    risk_score = (
        0.035 * rainfall_mm
        + 0.9 * water_level_m
        + 0.015 * humidity_percent
        + 0.012 * river_discharge_cumecs
        + 0.02 * soil_moisture_percent
        - 0.01 * elevation_m
        - 0.15 * days_since_last_rain
        + np.random.normal(0, 2.0, n_samples)  # noise
    )

    threshold = np.percentile(risk_score, 72)  # ~28% flood cases
    flood_occurred = (risk_score > threshold).astype(int)

    df = pd.DataFrame(
        {
            "rainfall_mm": rainfall_mm.round(2),
            "water_level_m": water_level_m.round(2),
            "humidity_percent": humidity_percent.round(2),
            "temperature_c": temperature_c.round(2),
            "river_discharge_cumecs": river_discharge_cumecs.round(2),
            "soil_moisture_percent": soil_moisture_percent.round(2),
            "elevation_m": elevation_m.round(2),
            "days_since_last_rain": days_since_last_rain.round(2),
            "flood_occurred": flood_occurred,
        }
    )
    return df


if __name__ == "__main__":
    df = generate_dataset()
    out_path = "data/flood_dataset.csv"
    df.to_csv(out_path, index=False)
    print(f"Generated {len(df)} rows -> {out_path}")
    print(df["flood_occurred"].value_counts(normalize=True))
